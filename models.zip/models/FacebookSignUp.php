<?php
require_once 'SignUpStrategy.php';
require_once 'Connection.php';

class FacebookSignUp implements SignUpStrategy {
    public function signUp($data) {
    // code for facebool sign up api 
    return "still dummy";
    }
}
?>