<?php
interface SignUpStrategy {
    public function signUp($data);
}
?>